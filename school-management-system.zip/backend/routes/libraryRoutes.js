const express = require("express");
const {
  getLibraryHistory,
  createLibraryRecord,
  updateLibraryRecord,
  deleteLibraryRecord,
} = require("../controllers/libraryController");
const { protect } = require("../middleware/authMiddleware");
const { roleMiddleware } = require("../middleware/roleMiddleware");

const router = express.Router();

router
  .route("/")
  .get(protect, roleMiddleware(["Admin", "Librarian"]), getLibraryHistory)
  .post(protect, roleMiddleware(["Admin", "Librarian"]), createLibraryRecord);

router
  .route("/:id")
  .put(protect, roleMiddleware(["Admin", "Librarian"]), updateLibraryRecord)
  .delete(protect, roleMiddleware(["Admin"]), deleteLibraryRecord);

module.exports = router;
