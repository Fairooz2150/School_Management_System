import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import * as feesAPI from "../api/feesAPI";

export const fetchFeesHistory = createAsyncThunk(
  "fees/fetchFeesHistory",
  async () => {
    return await feesAPI.fetchFeesHistory();
  }
);

const feesSlice = createSlice({
  name: "fees",
  initialState: {
    feesHistory: [],
    loading: false,
  },
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchFeesHistory.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchFeesHistory.fulfilled, (state, action) => {
        state.feesHistory = action.payload;
        state.loading = false;
      })
      .addCase(fetchFeesHistory.rejected, (state) => {
        state.loading = false;
      });
  },
});

export default feesSlice.reducer;
